<?php

function optima_get_demo_array($dir_url, $dir_path){

    $demo = array(
        'home-01-light-agency' => array(
            'title' 		=> 'Creative Light',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-01.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'demo-01.json',
            'preview'		=> $dir_url  . 'home-01.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 01 - Light Agency',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-01',
            'demo_url'      => 'http://optima.la-studioweb.com/home-01-light-agency'
        ),
        'home-02-digital-agency' => array(
            'title' 		=> 'Digital Agency',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-02.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-02.json',
            'preview'		=> $dir_url  . 'home-02.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 02 - Digital Agency',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-02',
            'demo_url'      => 'http://optima.la-studioweb.com/home-02-digital-agency'
        ),
        'home-03-creative-agency' => array(
            'title' 		=> 'Creative Agency',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-03.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-3.json',
            'option' 		=> $dir_path . 'home-03.json',
            'preview'		=> $dir_url  . 'home-03.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 03 - Creative Agency',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-03',
            'demo_url'      => 'http://optima.la-studioweb.com/home-03-creative-agency'
        ),
        'home-04-startup' => array(
            'title' 		=> 'Start Up',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-04.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-4.json',
            'option' 		=> $dir_path . 'home-04.json',
            'preview'		=> $dir_url  . 'home-04.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 04 - StartUp',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-04',
            'demo_url'      => 'http://optima.la-studioweb.com/home-04-startup'
        ),
        'home-05-creative-green' => array(
            'title' 		=> 'Creative Green',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-05.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-5.json',
            'option' 		=> $dir_path . 'home-05.json',
            'preview'		=> $dir_url  . 'home-05.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 05 - Creative Green',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-05',
            'demo_url'      => 'http://optima.la-studioweb.com/home-05-creative-green'
        ),
        'home-06-corporate-blue' => array(
            'title' 		=> 'Corporate Blue',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-06.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-6.json',
            'option' 		=> $dir_path . 'home-06.json',
            'preview'		=> $dir_url  . 'home-06.jpg',
            'menu-locations'=> array(
                'main-nav' 		=> 'Main Menu',
                'top-nav'       => 'Top Navigation',
                'footer-nav'    => 'Footer Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 06 - Corporate Blue',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-06',
            'demo_url'      => 'http://optima.la-studioweb.com/home-06-corporate-blue'
        ),
        'home-07-business' => array(
            'title' 		=> 'Business',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-07.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-7.json',
            'option' 		=> $dir_path . 'home-07.json',
            'preview'		=> $dir_url  . 'home-07.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 07 - Business',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-07',
            'demo_url'      => 'http://optima.la-studioweb.com/home-07-business'
        ),
        'home-08-finance' => array(
            'title' 		=> 'Finance',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-08.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-8.json',
            'option' 		=> $dir_path . 'home-08.json',
            'preview'		=> $dir_url  . 'home-08.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 08 - Finance',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-08',
            'demo_url'      => 'http://optima.la-studioweb.com/home-08-finance'
        ),
        'home-09-gym' => array(
            'title' 		=> 'Gym / Sport',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-09.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-9.json',
            'option' 		=> $dir_path . 'home-09.json',
            'preview'		=> $dir_url  . 'home-09.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 09 - Gym',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-09',
            'demo_url'      => 'http://optima.la-studioweb.com/home-09-gym'
        ),
        'home-10-restaurant' => array(
            'title' 		=> 'Restaurant',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-10.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-1.json',
            'option' 		=> $dir_path . 'home-10.json',
            'preview'		=> $dir_url  . 'home-10.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 10 - Restaurant',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-10',
            'demo_url'      => 'http://optima.la-studioweb.com/home-10-restaurant'
        ),
        'home-14-handmade-workshop' => array(
            'title' 		=> 'Handmade Workshop',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-14.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-14.json',
            'preview'		=> $dir_url  . 'home-14.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 14 - Handmade Workshop',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-14',
            'demo_url'      => 'http://optima.la-studioweb.com/home-14-handmade-workshop'
        ),
        'home-24-health-care' => array(
            'title' 		=> 'Health Care',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-24.json',
            'option' 		=> $dir_path . 'home-24.json',
            'preview'		=> $dir_url  . 'home-24.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 24 - Health Care',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-24',
            'demo_url'      => 'http://optima.la-studioweb.com/home-24-health-care'
        ),
        'home-16-portfolio-simple' => array(
            'title' 		=> 'Portfolio Simple',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-16.json',
            'option' 		=> $dir_path . 'home-16.json',
            'preview'		=> $dir_url  . 'home-16.jpg',
            'menu-locations'=> array(
                'main-nav' 		=> 'Main Menu',
                'top-nav'       => 'Top Navigation',
                'footer-nav'    => 'Footer Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 16 - Portfolio Simple',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-16',
            'demo_url'      => 'http://optima.la-studioweb.com/home-16-portfolio-simple'
        ),
        'home-17-portfolio-gallery' => array(
            'title' 		=> 'Portfolio Masonry',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-17.json',
            'option' 		=> $dir_path . 'home-17.json',
            'preview'		=> $dir_url  . 'home-17.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 17 - Portfolio Gallery',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-17',
            'demo_url'      => 'http://optima.la-studioweb.com/home-17-portfolio-gallery'
        ),
        'home-18-portfolio-split' => array(
            'title' 		=> 'Portfolio Split',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-18.json',
            'preview'		=> $dir_url  . 'home-18.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 18 - Portfolio Split',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-18',
            'demo_url'      => 'http://optima.la-studioweb.com/home-18-portfolio-split'
        ),
        'home-11-fashion' => array(
            'title' 		=> 'Clean & Minimal Store',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-11.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-11.json',
            'option' 		=> $dir_path . 'home-11.json',
            'preview'		=> $dir_url  . 'home-11.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 11 - Fashion',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-11',
            'demo_url'      => 'http://optima.la-studioweb.com/home-11-fashion'
        ),
        'home-12-fashion-sidebar' => array(
            'title' 		=> 'Sidebar Store',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-12.json',
            'option' 		=> $dir_path . 'home-12.json',
            'preview'		=> $dir_url  . 'home-12.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 12 - Fashion Sidebar',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-12',
            'demo_url'      => 'http://optima.la-studioweb.com/home-12-fashion-sidebar'
        ),
        'home-13-bikini-shop' => array(
            'title' 		=> 'Bikini Store',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-13.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-13.json',
            'preview'		=> $dir_url  . 'home-13.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 13 - Bikini Shop',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-13',
            'demo_url'      => 'http://optima.la-studioweb.com/home-13-bikini-shop'
        ),
        'home-19-architecture' => array(
            'title' 		=> 'Architecture 01',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-19.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widgets.json',
            'option' 		=> $dir_path . 'home-19.json',
            'preview'		=> $dir_url  . 'home-19.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 19 - Architecture',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-19',
            'demo_url'      => 'http://optima.la-studioweb.com/home-19-architecture'
        ),
        'home-20-construction' => array(
            'title' 		=> 'Construction',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-20.json',
            'preview'		=> $dir_url  . 'home-20.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 20 - Construction',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-20',
            'demo_url'      => 'http://optima.la-studioweb.com/home-20-construction'
        ),
        'home-21-architecture-full-slider' => array(
            'title' 		=> 'Architecture 02',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-21.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-21.json',
            'option' 		=> $dir_path . 'home-21.json',
            'preview'		=> $dir_url  . 'home-21.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 21 - Architecture Full slider',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-21',
            'demo_url'      => 'http://optima.la-studioweb.com/home-21-architecture-full-slider'
        ),
        'home-22-beauty-spa' => array(
            'title' 		=> 'Spa / Beauty',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'home-22.zip',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-22.json',
            'option' 		=> $dir_path . 'home-22.json',
            'preview'		=> $dir_url  . 'home-22.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Fashion 01',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-22',
            'demo_url'      => 'http://optima.la-studioweb.com/home-22-beauty-spa'
        ),
        'home-23-furniture' => array(
            'title' 		=> 'Furniture',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-23.json',
            'option' 		=> $dir_path . 'home-23.json',
            'preview'		=> $dir_url  . 'home-23.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 23 - Furniture',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-23',
            'demo_url'      => 'http://optima.la-studioweb.com/home-23-furniture'
        ),
        'home-25-freelancer' => array(
            'title' 		=> 'Freelancer',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'home-25.json',
            'preview'		=> $dir_url  . 'home-25.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 25 - Freelancer',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-25',
            'demo_url'      => 'http://optima.la-studioweb.com/home-25-freelancer'
        ),
        'home-15-fashion-full-screen' => array(
            'title' 		=> 'Full Parallax',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'optima-content.xml',
            'widget' 		=> $dir_path . 'widget-15.json',
            'option' 		=> $dir_path . 'home-15.json',
            'preview'		=> $dir_url  . 'home-15.jpg',
            'menu-locations'=> array(
                'top-nav'       => 'Top Menu',
                'main-nav'      => 'Main Menu',
                'aside-nav' 	=> 'Aside Menu'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Home 15 - Fashion Full Screen',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'demo-15',
            'demo_url'      => 'http://optima.la-studioweb.com/home-15-fashion-full-screen/'
        ),
        'modern-coming-soon' => array(
            'title' 		=> 'Modern Coming Soon',
            'category'      => 'demo',
            'preview'		=> $dir_url  . 'modern-coming-soon.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/modern-coming-soon'
        ),
        'business-coming-soon' => array(
            'title' 		=> 'Business Coming Soon',
            'category'      => 'demo',
            'preview'		=> $dir_url  . 'business-coming-soon.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/business-coming-soon/'
        ),
        'about-01' => array(
            'title' 		=> 'About Us 01',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'about-01.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/about-us/'
        ),
        'about-02' => array(
            'title' 		=> 'About Us 02',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'about-02.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/about-us-02/'
        ),
        'about-me' => array(
            'title' 		=> 'About Me',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'about-me.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/about-me/'
        ),
        'our-services-01' => array(
            'title' 		=> 'Our Services 01',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'our-services-01.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/our-services/'
        ),
        'our-services-02' => array(
            'title' 		=> 'Our Services 02',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'our-services-02.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/our-services-02/'
        ),
        '404' => array(
            'title' 		=> '404 Page',
            'category'      => 'inner',
            'preview'		=> $dir_url  . '404.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/404'
        ),
        'contact-us-01' => array(
            'title' 		=> 'Contact Us 01',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'contact-us-01.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/contact-us/'
        ),
        'contact-us-02' => array(
            'title' 		=> 'Contact Us 02',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'contact-us-02.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/contact-us-02/'
        ),
        'contact-us-03' => array(
            'title' 		=> 'Contact Us 03',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'contact-us-03.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/contact-us-03/'
        ),
        'faq-01' => array(
            'title' 		=> 'FAQs 01',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'faq-01.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/faqs-01/'
        ),
        'faq-02' => array(
            'title' 		=> 'FAQs 02',
            'category'      => 'inner',
            'preview'		=> $dir_url  . 'faq-02.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/faqs-02/'
        ),
        'portfolio-fullwidth' => array(
            'title' 		=> 'Portfolio FullWidth',
            'category'      => 'portfolio_list',
            'preview'		=> $dir_url  . 'portfolio-fullwidth.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/portfolio-fullwidth/'
        ),
        'portfolio-masonry-3' => array(
            'title' 		=> 'Portfolio No Padding',
            'category'      => 'portfolio_list',
            'preview'		=> $dir_url  . 'portfolio-masonry-3.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/portfolio-masonry-03/'
        ),
        'portfolio-classic-1' => array(
            'title' 		=> 'Classic 01',
            'category'      => 'portfolio_list',
            'preview'		=> $dir_url  . 'portfolio-classic-1.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/portfolio-classic/'
        ),
        'portfolio-classic-2' => array(
            'title' 		=> 'Classic 02',
            'category'      => 'portfolio_list',
            'preview'		=> $dir_url  . 'portfolio-classic-1.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/portfolio-classic-02/'
        ),
        'portfolio-parallax' => array(
            'title' 		=> 'Parallax',
            'category'      => 'portfolio_list',
            'preview'		=> $dir_url  . 'portfolio-parallax.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/portfolio-parallax/'
        ),
        'portfolio-masonry-1' => array(
            'title' 		=> 'Grid Layout',
            'category'      => 'portfolio_list',
            'preview'		=> $dir_url  . 'portfolio-masonry.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pages/portfolio-masonry/'
        ),
        'single-blog-1' => array(
            'title' 		=> 'Single Blog 01',
            'category'      => 'single_blog',
            'preview'		=> $dir_url  . 'single-blog-1.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/lorem-ipsum-dolor/?la_preset=related_post_1'
        ),
        'single-blog-2' => array(
            'title' 		=> 'Single Blog 02',
            'category'      => 'single_blog',
            'preview'		=> $dir_url  . 'single-blog-2.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/pictures-in-the-sky/?la_preset=related_post_2'
        ),
        'single-blog-3' => array(
            'title' 		=> 'Single Blog 03',
            'category'      => 'single_blog',
            'preview'		=> $dir_url  . 'single-blog-3.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/cheap-romantic-vacations/?la_preset=related_post_3'
        ),
        'shop-fullwidth' => array(
            'title' 		=> 'Shop Fullwidth',
            'category'      => 'shop_page',
            'preview'		=> $dir_url  . 'shop-fullwidth.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/shop/?la_preset=shop-fullwidth'
        ),
        'shop-sidebar' => array(
            'title' 		=> 'Shop Sidebar',
            'category'      => 'shop_page',
            'preview'		=> $dir_url  . 'shop-sidebar.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/shop/?la_preset=shop-sidebar'
        ),
        'shop-single-1' => array(
            'title' 		=> 'Single Product 01',
            'category'      => 'shop_page',
            'preview'		=> $dir_url  . 'shop-single-1.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/shop/vans-off-the-wall-t-shirt-in-2/?la_preset=product_01'
        ),
        'shop-single-2' => array(
            'title' 		=> 'Single Product 02',
            'category'      => 'shop_page',
            'preview'		=> $dir_url  . 'shop-single-2.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/shop/supreme-being-icon-glitch-t-shirt-3/?la_preset=product_02'
        ),
        'shop-single-var' => array(
            'title' 		=> 'Single Variations',
            'category'      => 'shop_page',
            'preview'		=> $dir_url  . 'shop-single-var.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/shop/product-variations/'
        ),
        'shop-single-sidebar' => array(
            'title' 		=> 'Single Sidebar',
            'category'      => 'shop_page',
            'preview'		=> $dir_url  . 'shop-single-sidebar.jpg',
            'demo_url'      => 'http://optima.la-studioweb.com/shop/vans-off-the-wall-t-shirt-in-2/?la_preset=product-sidebar'
        )
    );

    return $demo;

}