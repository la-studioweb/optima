<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_10(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2532
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2533
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2532
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2533
        ),
        array(
            'key' => 'header_layout',
            'value' => 2
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Merriweather',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Playfair Display',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'highlight_font',
            'value' => array (
                'family' => 'Mr Dafoe',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => 'rgba(0, 0, 0, 0.8)'
            )
        ),
        array(
            'key' => 'header_link_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mm_lv_1_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'mm_lv_1_hover_bg_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_bg_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '1col12'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#1c1d23'
            )
        ),
        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#1c1d23'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-10-footer-column-1'
        )
    );
}