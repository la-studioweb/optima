<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_12(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2539
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2540
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2539
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2540
        ),
        array(
            'key' => 'header_layout',
            'value' => 9
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'yes'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Poppins',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Playfair Display',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#f7f7f7'
            )
        ),
        array(
            'key' => 'offcanvas_text_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_heading_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_link_color',
            'value' => '#343538'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '1col12'
        ),
        array(
            'filter_name' => 'optima/filter/aside_widget_bottom',
            'value' => 'home-12-header-aside'
        )
    );
}