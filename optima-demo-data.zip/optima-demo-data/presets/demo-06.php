<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_06(){
    return array(
        array(
            'key' => 'logo_transparency',
            'value' => 1895
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => ''
        ),
        array(
            'key' => 'header_layout',
            'value' => 8
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#3f54c0'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#3f54c0'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#3f54c0'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#3f54c0'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#3f54c0'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#3f54c0'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '2col48'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-06-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'home-05-footer-column-2'
        )
    );
}