<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_08(){
    return array(
        array(
            'key' => 'logo',
            'value' => 1910
        ),
        array(
            'key' => 'logo_2x',
            'value' => 1911
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 1910
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 1911
        ),
        array(
            'key' => 'header_layout',
            'value' => 7
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Roboto',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Roboto',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#232324'
            )
        ),
        array(
            'key' => 'header_top_text_color',
            'value' => 'rgba(255,255,255,0.4)'
        ),
        array(
            'key' => 'header_top_link_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_top_link_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'header_text_color',
            'value' => '#9d9d9d'
        ),
        array(
            'key' => 'header_link_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#d9770e'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#d9770e'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-08-footer-column-1'
        )
    );
}