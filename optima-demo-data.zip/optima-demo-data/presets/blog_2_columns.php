<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_blog_2_columns(){
    return array(
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'format_content_blog',
            'value' => 'on'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '570x350'
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array(
                'lg' => 2,
                'md' => 2,
                'sm' => 2,
                'xs' => 1,
                'mb' => 1
            )
        ),
        array(
            'filter_name' => 'optima/filter/page_title',
            'value' => '<header><div class="page-title h4">Blog 02 Columns</div></header>'
        )
    );
}