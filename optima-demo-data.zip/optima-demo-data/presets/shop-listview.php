<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_shop_listview(){
    return array(
        array(
            'key' => 'layout_archive_product',
            'value' => 'col-2cr'
        ),
        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 3,
                'lg' => 3,
                'md' => 2,
                'sm' => 3,
                'xs' => 1,
                'mb' => 1
            )
        ),
        array(
            'key' => 'shop_catalog_display_type',
            'value' => 'list'
        ),
        array(
            'key' => 'product_per_page_allow',
            'value' => '6,9,15'
        ),
        array(
            'key' => 'product_per_page_default',
            'value' => 6
        ),
        array(
            'filter_name' => 'optima/filter/page_title',
            'value' => '<header><div class="page-title h1">Shop List View</div></header>'
        )
    );
}