<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_20(){
    return array(
        array(
            'key' => 'logo',
            'value' => 2562
        ),
        array(
            'key' => 'logo_2x',
            'value' => 2563
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 2562
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 2563
        ),
        array(
            'key' => 'main_font',
            'value' => array (
                'family' => 'Roboto Slab',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array (
                'family' => 'Roboto Slab',
                'font' => 'google',
                'variant' => array (
                    '300',
                    '300italic',
                    'regular',
                    'italic',
                    '700',
                    '700italic',
                )
            )
        ),
        array(
            'key' => 'header_layout',
            'value' => 8
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'header_background',
            'value' => array(
                'color' => 'rgba(0,0,0,0)'
            )
        ),
        array(
            'key' => 'transparency_header_background',
            'value' => array(
                'color' => 'rgba(0,0,0,0)'
            )
        ),
        array(
            'key' => 'primary_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#f5b324'
        )
    );
}