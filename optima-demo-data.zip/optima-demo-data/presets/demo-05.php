<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_optima_preset_demo_05(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#71c539'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#71c539'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#71c539'
        ),
        array(
            'key' => 'offcanvas_link_hover_color',
            'value' => '#71c539'
        ),
        array(
            'key' => 'transparency_header_link_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mb_lv_2_hover_bg_color',
            'value' => '#71c539'
        ),
        array(
            'key' => 'mb_lv_1_hover_color',
            'value' => '#71c539'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '2col48'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_1',
            'value' => 'home-05-footer-column-1'
        ),
        array(
            'filter_name' => 'optima/filter/footer_column_2',
            'value' => 'home-05-footer-column-2'
        )
    );
}